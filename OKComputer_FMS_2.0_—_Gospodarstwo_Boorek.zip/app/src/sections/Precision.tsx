import { useMemo, useState } from 'react';
import { useFarm } from '@/store/FarmContext';
import { Btn, Card, fmtNum, Input, SectionTitle, Select } from '@/components/common';

export default function Precision() {
  const { state, notify } = useFarm();
  const [fieldId, setFieldId] = useState(state.fields[0]?.id || '');
  const [product, setProduct] = useState('Saletra amonowa 34%');
  const [base, setBase] = useState(250);
  const [min, setMin] = useState(120);
  const [max, setMax] = useState(360);
  const field = state.fields.find((f) => f.id === fieldId);

  // generowanie stref VRA na podstawie deterministycznego "szumu"
  const zones = useMemo(() => {
    if (!field) return [];
    const zonesCount = 4;
    const seed = field.name.length + field.area;
    const grid: number[][] = [];
    for (let y = 0; y < 10; y++) {
      const row: number[] = [];
      for (let x = 0; x < 14; x++) {
        const v = Math.sin((x + seed) * 0.7) * Math.cos((y + seed) * 0.9) + Math.sin((x + y) * 0.4);
        row.push(v);
      }
      grid.push(row);
    }
    const flat = grid.flat().sort((a, b) => a - b);
    return grid.map((row) => row.map((v) => {
      const rank = flat.indexOf(v) / flat.length;
      const zone = Math.min(zonesCount - 1, Math.floor(rank * zonesCount));
      return zone;
    }));
  }, [field]);

  const zoneDoses = [min, min + (max - min) * 0.33, min + (max - min) * 0.66, max];
  const zoneColors = ['#ef4444', '#f59e0b', '#a3e635', '#10b981'];
  const stats = useMemo(() => {
    const counts = [0, 0, 0, 0];
    zones.flat().forEach((z) => counts[z]++);
    const total = zones.flat().length;
    const avg = zones.flat().reduce((a, z) => a + zoneDoses[z], 0) / Math.max(total, 1);
    return { counts, total, avg, totalProduct: field ? (avg * field.area) / 1000 : 0, flat: 0 };
  }, [zones, field, zoneDoses]);

  const exportVra = (format: string) => {
    if (!field) return;
    const content = `<?xml version="1.0" encoding="UTF-8"?>\n<!-- TASKDATA.XML — struktura przygotowana pod ISO-XML (DEMO) -->\n<TASKDATA>\n  <TSK A="${field.name}" B="${field.area} ha" C="${product}"/>\n  <VPN A="${base}" B="${min}" C="${max}" D="kg/ha"/>\n  <GRD A="10x14" B="${stats.avg.toFixed(0)} kg/ha średnio"/>\n</TASKDATA>`;
    const blob = new Blob([content], { type: 'application/xml' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `VRA_${field.name.replace(/\s+/g, '_')}_${format.toLowerCase()}.xml`;
    a.click();
    notify(`Wyeksportowano mapę VRA (${format})`);
  };

  return (
    <div className="space-y-4">
      <SectionTitle title="📡 Rolnictwo Precyzyjne" sub="Indeksy wegetacji, mapy zasobności i generator map VRA (dane DEMO)" />

      <div className="grid md:grid-cols-4 gap-3">
        {[
          { name: 'NDVI', v: '0,72', desc: 'wigor łanu — dobry', color: '#10b981' },
          { name: 'NDRE', v: '0,41', desc: 'zawartość chlorofilu', color: '#38bdf8' },
          { name: 'Zasobność N', v: 'średnia', desc: 'mapa azotowa (DEMO)', color: '#f59e0b' },
          { name: 'Mapa plonu 2025', v: '7,4 t/ha', desc: 'średnia ważona', color: '#a78bfa' },
        ].map((x) => (
          <Card key={x.name} className="!p-3 text-center">
            <div className="text-xs text-slate-400">{x.name}</div>
            <div className="text-2xl font-bold mt-1" style={{ color: x.color }}>{x.v}</div>
            <div className="text-[11px] text-slate-500">{x.desc}</div>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <h4 className="font-semibold text-slate-100 mb-3">🗺️ Mapa stref VRA — {field?.name}</h4>
          {field && (
            <svg viewBox="0 0 140 100" className="w-full h-72 rounded-lg bg-slate-900 border border-slate-700/50">
              {zones.map((row, y) => row.map((z, x) => (
                <rect key={`${x}-${y}`} x={x * 10} y={y * 10} width={10} height={10} fill={zoneColors[z]} opacity={0.75} />
              )))}
            </svg>
          )}
          <div className="flex flex-wrap gap-3 mt-3 text-xs">
            {zoneDoses.map((d, i) => (
              <span key={i} className="flex items-center gap-1.5 text-slate-300">
                <span className="w-3 h-3 rounded-sm inline-block" style={{ background: zoneColors[i] }} />
                Strefa {i + 1}: {Math.round(d)} kg/ha ({Math.round((stats.counts[i] / Math.max(stats.total, 1)) * 100)}% pow.)
              </span>
            ))}
          </div>
        </Card>

        <Card>
          <h4 className="font-semibold text-slate-100 mb-3">⚙️ Generator mapy VRA</h4>
          <div className="grid gap-3">
            <Select label="Pole" value={fieldId} onChange={(e) => setFieldId(e.target.value)}>
              {state.fields.map((f) => <option key={f.id} value={f.id}>{f.name} ({fmtNum(f.area)} ha)</option>)}
            </Select>
            <Select label="Nawóz" value={product} onChange={(e) => setProduct(e.target.value)}>
              {['Saletra amonowa 34%', 'Saletrzak 27%', 'RSM 32%', 'Polifoska 6', 'Sól potasowa 60%'].map((x) => <option key={x}>{x}</option>)}
            </Select>
            <div className="grid grid-cols-3 gap-2">
              <Input label="Bazowa kg/ha" type="number" value={base} onChange={(e) => setBase(+e.target.value)} />
              <Input label="Min kg/ha" type="number" value={min} onChange={(e) => setMin(+e.target.value)} />
              <Input label="Max kg/ha" type="number" value={max} onChange={(e) => setMax(+e.target.value)} />
            </div>
            <div className="rounded-lg bg-slate-900/60 border border-slate-700/50 p-3 text-sm space-y-1">
              <div className="flex justify-between"><span className="text-slate-400">Średnia dawka</span><b className="text-emerald-400">{fmtNum(stats.avg, 0)} kg/ha</b></div>
              <div className="flex justify-between"><span className="text-slate-400">Zapotrzebowanie</span><b className="text-emerald-400">{fmtNum(stats.totalProduct, 2)} t</b></div>
              <div className="flex justify-between"><span className="text-slate-400">Oszczędność vs dawka stała</span><b className="text-sky-400">{fmtNum(((base * (field?.area || 0)) / 1000 - stats.totalProduct), 2)} t</b></div>
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-1.5">Eksport (struktura ISO-XML / TASKDATA.XML):</div>
              <div className="flex gap-2">
                <Btn variant="outline" className="flex-1 !py-1.5 text-xs" onClick={() => exportVra('ISO-XML')}>ISO-XML</Btn>
                <Btn variant="outline" className="flex-1 !py-1.5 text-xs" onClick={() => exportVra('TASKDATA')}>TASKDATA.XML</Btn>
                <Btn variant="outline" className="flex-1 !py-1.5 text-xs" onClick={() => exportVra('VRA')}>Plik VRA</Btn>
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5">Wersja DEMO eksportuje poprawną strukturę XML; pełna zgodność z terminalami ISOBUS wymaga modułu produkcyjnego.</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
