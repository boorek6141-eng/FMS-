import { useMemo, useRef, useState, useEffect } from 'react';
import { useFarm } from '@/store/FarmContext';
import { Badge, fmtNum, fmtPLN } from '@/components/common';

interface Msg { role: 'user' | 'ai'; text: string }

const SUGGESTED = [
  'Co powinienem zrobić dzisiaj?',
  'Które pola wymagają uwagi?',
  'Ile nawozu potrzebuję na 50 ha?',
  'Które pole jest najbardziej rentowne?',
  'Jakie zabiegi wykonałem na Polu 3?',
  'Ile paliwa zużyłem w tym miesiącu?',
  'Co mam w magazynie?',
  'Które maszyny wymagają serwisu?',
];

export default function AI() {
  const { state } = useFarm();
  const [msgs, setMsgs] = useState<Msg[]>([{ role: 'ai', text: 'Cześć! Jestem Agro AI — demonstracyjny asystent gospodarstwa (TRYB DEMO — odpowiedzi generuję lokalnie z danych aplikacji, nie łączę się z prawdziwym modelem AI). Zapytaj mnie o pola, zadania, magazyn, maszyny lub finanse.' }]);
  const [input, setInput] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  const answer = useMemo(() => (q: string): string => {
    const s = q.toLowerCase();
    const today = '2026-08-06';

    if (s.includes('dzisiaj') || s.includes('dziś') || s.includes('co powinienem')) {
      const tasks = state.tasks.filter((t) => t.dueDate <= today && t.status !== 'wykonane');
      if (tasks.length === 0) return 'Na dziś nie masz zaległych zadań. 🎉 Najbliższe zaplanowane zadania znajdziesz w module Pracownicy i Zadania.';
      return `Na dziś masz ${tasks.length} zadań:\n${tasks.map((t) => `• ${t.title} (priorytet: ${t.priority}${t.fieldId ? `, pole: ${state.fields.find((f) => f.id === t.fieldId)?.name}` : ''})`).join('\n')}\n\nPogoda (DEMO): 24°C, wiatr 2,1 m/s, bez opadów — warunki do oprysków dobre.`;
    }
    if (s.includes('uwagi') || s.includes('uwagę')) {
      const alerts = state.alerts.filter((a) => !a.read && a.priority !== 'info');
      return `Pola/sytuacje wymagające uwagi (${alerts.length} aktywnych alertów):\n${alerts.map((a) => `${a.priority === 'krytyczne' ? '🔴' : '🟡'} ${a.title}`).join('\n') || '• brak krytycznych alertów'}`;
    }
    if (s.includes('nawoz') && /\d+/.test(s)) {
      const ha = parseFloat(s.match(/(\d+[.,]?\d*)/)?.[1].replace(',', '.') || '0');
      const dose = 250; // kg/ha saletry
      return `Przy średniej dawce saletry amonowej 34% ok. 250 kg/ha, na ${ha} ha potrzebujesz ok. ${fmtNum((dose * ha) / 1000, 2)} t saletry.\nW magazynie masz: ${fmtNum(state.warehouse.find((w) => w.name.includes('Saletra'))?.stock || 0, 0)} kg saletry amonowej.\nDokładną dawkę policz w kalkulatorze NPK+S (moduł Nawożenie).`;
    }
    if (s.includes('rentown')) {
      const perField = state.fields.map((f) => {
        const fc = state.fieldCrops.find((c) => c.fieldId === f.id && c.season === 2026);
        const costs = state.treatments.filter((t) => t.fieldId === f.id && t.season === 2026).reduce((a, t) => a + t.cost, 0) + f.area * 900;
        const rev = fc ? fc.plannedYield * f.area * 800 : 0;
        return { name: f.name, margin: (rev - costs) / f.area };
      }).sort((a, b) => b.margin - a.margin);
      return `Ranking rentowności (marża/ha, prognoza 2026):\n${perField.slice(0, 5).map((x, i) => `${i + 1}. ${x.name} — ${fmtPLN(x.margin)}/ha`).join('\n')}\nSzczegóły w module Finanse.`;
    }
    if (s.includes('paliw')) {
      const fuel = state.fuelTanks.reduce((a, t) => a + t.current, 0);
      const used = state.fuelTanks.flatMap((t) => t.history).filter((h) => h.type === 'zużycie').reduce((a, h) => a + h.qty, 0);
      return `Stan paliwa: ${fmtNum(fuel, 0)} l ON w ${state.fuelTanks.length} zbiornikach.\nZarejestrowane zużycie: ${fmtNum(used, 0)} l (ostatnio: żniwa — Claas Lexion 320 l, JD 6195R 180 l).\nSzczegóły: Magazyn → Magazyn paliwa.`;
    }
    if (s.includes('magazyn')) {
      const low = state.warehouse.filter((w) => w.stock <= w.minStock);
      const val = state.warehouse.reduce((a, w) => a + w.stock * w.price, 0);
      return `W magazynie masz ${state.warehouse.length} produktów o łącznej wartości ${fmtPLN(val)}.\n⚠️ Niskie stany (${low.length}): ${low.map((w) => `${w.name} (${fmtNum(w.stock, 0)} ${w.unit})`).join(', ') || 'brak'}.\nPłody rolne: ${state.grain.map((g) => `${g.crop} ${fmtNum(g.qty, 0)} t`).join(', ')}.`;
    }
    if (s.includes('serwis') || s.includes('maszyn')) {
      const need = state.machines.filter((m) => m.nextServiceMth - m.mth < 150);
      return `Maszyny wymagające serwisu (<150 MTH do przeglądu):\n${need.map((m) => `• ${m.name} — przegląd za ${m.nextServiceMth - m.mth} MTH (stan: ${fmtNum(m.mth, 0)} MTH)`).join('\n') || '• żadna — wszystkie maszyny sprawne'}\nNajbliższa atestacja: opryskiwacz Amazone UX — 20.08.2026.`;
    }
    if (s.includes('zabieg') || s.includes('polu')) {
      const num = parseInt(s.match(/polu?\s*(\d+)/)?.[1] || '0');
      const field = num > 0 ? state.fields[num - 1] : state.fields.find((f) => s.includes(f.name.toLowerCase()));
      if (field) {
        const tr = state.treatments.filter((t) => t.fieldId === field.id).sort((a, b) => b.date.localeCompare(a.date));
        return `Zabiegi na polu „${field.name}” (${tr.length}):\n${tr.slice(0, 8).map((t) => `• ${t.date} — ${t.type}${t.productName ? ` (${t.productName})` : ''}`).join('\n') || '• brak zabiegów'}`;
      }
      return 'Nie znalazłem tego pola. Podaj numer (np. „Polu 3”) lub nazwę pola.';
    }
    if (s.includes('plon')) {
      const tot = state.fieldCrops.filter((c) => c.season === 2026).reduce((a, c) => {
        const f = state.fields.find((x) => x.id === c.fieldId);
        return a + (f ? c.plannedYield * f.area : 0);
      }, 0);
      return `Przewidywany łączny plon sezonu 2026: ok. ${fmtNum(tot / 1000, 2)} tys. t przy areale ${fmtNum(state.fields.reduce((a, f) => a + f.area, 0))} ha. Szczegóły: moduł Finanse → wykres „Plon z hektara”.`;
    }
    return 'Jestem w trybie DEMO i rozumiem pytania o: zadania na dziś, pola wymagające uwagi, nawozy, rentowność, zabiegi na polach, paliwo, magazyn, serwisy maszyn i plony. Po podłączeniu API AI będę odpowiadał na dowolne pytania o gospodarstwo.';
  }, [state]);

  const ask = (q: string) => {
    if (!q.trim()) return;
    setMsgs((m) => [...m, { role: 'user', text: q }, { role: 'ai', text: answer(q) }]);
    setInput('');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-210px)] min-h-[480px]">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-xl font-bold text-slate-100">🤖 Agro AI — Copilot Gospodarstwa</h2>
          <p className="text-sm text-slate-400">Asystent korzysta z danych aplikacji</p>
        </div>
        <Badge tone="info">TRYB DEMO — bez połączenia z modelem AI</Badge>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pr-1">
        {msgs.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-wrap ${m.role === 'user' ? 'bg-emerald-600/80 text-white rounded-br-md' : 'bg-slate-800/80 border border-slate-700/60 text-slate-100 rounded-bl-md'}`}>
              {m.role === 'ai' && <span className="mr-1.5">🤖</span>}{m.text}
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <div className="mt-3">
        <div className="flex gap-1.5 flex-wrap mb-2">
          {SUGGESTED.slice(0, 4).map((q) => (
            <button key={q} onClick={() => ask(q)} className="px-2.5 py-1 rounded-full text-xs border border-slate-600 text-slate-300 hover:border-emerald-500 transition-colors">{q}</button>
          ))}
        </div>
        <div className="flex gap-2">
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && ask(input)}
            placeholder="Zapytaj o gospodarstwo…" className="flex-1 bg-slate-800/70 border border-slate-600 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-emerald-500 placeholder:text-slate-500" />
          <button onClick={() => ask(input)} className="px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition-colors">Wyślij</button>
        </div>
      </div>
    </div>
  );
}
