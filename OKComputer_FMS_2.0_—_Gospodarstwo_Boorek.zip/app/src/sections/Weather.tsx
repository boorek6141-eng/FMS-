import { WEATHER_FORECAST } from '@/data/demo';
import { Badge, Card, fmtDate, SectionTitle } from '@/components/common';
import type { WeatherDay } from '@/types';

function sprayVerdict(d: WeatherDay): { tone: 'ok' | 'warn' | 'bad'; label: string; reasons: string[] } {
  const reasons: string[] = [];
  let score = 0;
  if (d.wind > 4) { score += 2; reasons.push(`Wiatr ${d.wind} m/s — zbyt silny (limit 4 m/s, ryzyko znoszenia cieczy)`); }
  else if (d.wind > 2.5) { score += 1; reasons.push(`Wiatr ${d.wind} m/s — graniczny, opryskuj przy niskim ciśnieniu`); }
  else reasons.push(`Wiatr ${d.wind} m/s — korzystny`);
  if (d.gusts > 8) { score += 2; reasons.push(`Porywy do ${d.gusts} m/s — niebezpieczne znoszenie`); }
  if (d.temp > 25) { score += 1; reasons.push(`Temperatura ${d.temp}°C — ryzyko parowania kropli (pracuj rano/wieczorem)`); }
  if (d.temp < 5) { score += 2; reasons.push(`Za zimno (${d.temp}°C)`); }
  if (d.rain > 0) { score += 2; reasons.push(`Opady ${d.rain} mm — oprysk zostanie zmymty`); }
  if (d.humidity < 50) { score += 1; reasons.push(`Niska wilgotność ${d.humidity}% — szybkie wysychanie kropli`); }
  if (d.humidity > 85) { score += 1; reasons.push(`Bardzo wysoka wilgotność ${d.humidity}% — ryzyko infekcji grzybowych`); }
  if (reasons.length === 0 || (score === 0)) reasons.push('Wszystkie parametry w optymalnym zakresie');
  return score >= 3 ? { tone: 'bad', label: 'WARUNKI NIEKORZYSTNE', reasons } : score >= 1 ? { tone: 'warn', label: 'WARUNKI WARUNKOWE', reasons } : { tone: 'ok', label: 'WARUNKI DOBRE', reasons };
}

export default function Weather() {
  const today = WEATHER_FORECAST[0];
  const v = sprayVerdict(today);
  const tones = { ok: 'border-emerald-500/50 bg-emerald-900/20', warn: 'border-amber-500/50 bg-amber-900/20', bad: 'border-red-500/50 bg-red-900/20' };
  const badgeT = { ok: 'ok', warn: 'warn', bad: 'bad' } as const;

  return (
    <div className="space-y-4">
      <SectionTitle title="🌦️ Pogoda i Okna Zabiegowe" sub="Dane demonstracyjne (DEMO) — architektura przygotowana pod API pogodowe (np. OpenWeather, IMGW)" right={<Badge tone="info">DANE DEMO</Badge>} />

      <Card className={`border ${tones[v.tone]}`}>
        <div className="flex flex-wrap items-center gap-5">
          <div className="text-6xl">{today.icon}</div>
          <div>
            <h3 className="text-lg font-bold text-slate-100">Czy mogę dziś opryskiwać?</h3>
            <div className={`text-2xl font-black mt-1 ${v.tone === 'ok' ? 'text-emerald-400' : v.tone === 'warn' ? 'text-amber-400' : 'text-red-400'}`}>
              {v.tone === 'ok' ? '🟢' : v.tone === 'warn' ? '🟡' : '🔴'} {v.label}
            </div>
          </div>
          <div className="ml-auto grid grid-cols-3 gap-x-6 gap-y-1 text-sm text-slate-300">
            <span>🌡️ {today.temp}°C (min. {today.tempMin}°C)</span>
            <span>🌬️ {today.wind} m/s</span>
            <span>💨 porywy {today.gusts} m/s</span>
            <span>💧 {today.humidity}%</span>
            <span>🌧️ {today.rain} mm</span>
            <span>{today.desc}</span>
          </div>
        </div>
        <div className="mt-4 border-t border-slate-700/40 pt-3">
          <div className="text-xs text-slate-400 uppercase mb-1.5">Dlaczego?</div>
          <ul className="text-sm text-slate-200 space-y-1">
            {v.reasons.map((r, i) => <li key={i}>• {r}</li>)}
          </ul>
        </div>
      </Card>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-3">
        {WEATHER_FORECAST.map((d) => {
          const dv = sprayVerdict(d);
          return (
            <Card key={d.date} className="!p-3 text-center">
              <div className="text-xs text-slate-400">{fmtDate(d.date)}</div>
              <div className="text-3xl my-1.5">{d.icon}</div>
              <div className="font-bold text-slate-100">{d.temp}°C <span className="text-xs font-normal text-slate-500">/ {d.tempMin}°</span></div>
              <div className="text-[11px] text-slate-400 mt-1 space-y-0.5">
                <div>🌬️ {d.wind} m/s (porywy {d.gusts})</div>
                <div>💧 {d.humidity}% · 🌧️ {d.rain} mm</div>
              </div>
              <div className="mt-2"><Badge tone={badgeT[dv.tone]}>{dv.tone === 'ok' ? '🟢 oprysk OK' : dv.tone === 'warn' ? '🟡 warunkowo' : '🔴 nie opryskiwać'}</Badge></div>
            </Card>
          );
        })}
      </div>

      <Card>
        <h4 className="font-semibold text-slate-100 mb-2">📅 Okna zabiegowe — podsumowanie tygodnia</h4>
        <div className="space-y-1.5 text-sm">
          {WEATHER_FORECAST.map((d) => {
            const dv = sprayVerdict(d);
            return (
              <div key={d.date} className="flex items-center gap-3 rounded-lg bg-slate-900/40 border border-slate-700/40 px-3 py-2">
                <span className="w-24 text-slate-300">{fmtDate(d.date)}</span>
                <Badge tone={badgeT[dv.tone]}>{dv.label}</Badge>
                <span className="text-xs text-slate-400 hidden md:block">{dv.reasons[0]}</span>
              </div>
            );
          })}
        </div>
        <p className="text-xs text-slate-500 mt-3">Po podłączeniu API pogodowego moduł automatycznie odświeży analizę co godzinę i wyśle alert o najbliższym oknie zabiegowym.</p>
      </Card>
    </div>
  );
}
