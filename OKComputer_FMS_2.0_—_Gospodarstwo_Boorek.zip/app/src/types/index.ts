export type ID = string;

export interface Farm {
  id: ID;
  name: string;
  owner: string;
  location: string;
}

export interface Field {
  id: ID;
  name: string;
  area: number; // ha
  parcelNo: string;
  district: string; // obręb
  soilType: string;
  pH: number;
  P: string; // zasobność
  K: string;
  Mg: string;
  geo: [number, number][]; // [lat, lng] — granice pola na mapie
  cropId?: ID; // aktualna uprawa (FieldCrop)
}

export interface FieldCrop {
  id: ID;
  fieldId: ID;
  cropName: string;
  variety: string;
  season: number;
  sowingDate: string;
  plannedYield: number; // t/ha
  actualYield?: number;
  bbch: number;
}

export interface CropHistory {
  id: ID;
  fieldId: ID;
  season: number;
  crop: string;
  variety: string;
  yield: number; // t/ha
  costs: number; // PLN
  revenue: number; // PLN
  notes: string;
}

export interface CropInfo {
  name: string;
  category: string;
  sowingWindow: string;
  seedRate: string; // norma siewu
  mtz: number; // g
  density: string; // obsada
  potentialYield: number; // t/ha
  productionCost: number; // PLN/ha
  fertReq: string; // wymagania nawozowe
}

export interface Treatment {
  id: ID;
  date: string;
  type: string; // oprysk, nawożenie, siew...
  fieldId: ID;
  crop: string;
  machineId?: ID;
  operator?: string;
  productId?: ID;
  productName?: string;
  dose?: number; // kg/ha lub l/ha
  quantity?: number; // kg lub l całość
  weather?: string;
  notes?: string;
  cost: number; // PLN
  season: number;
}

export interface Machine {
  id: ID;
  name: string;
  category: string;
  brand: string;
  model: string;
  year: number;
  regNo: string;
  mth: number;
  nextServiceMth: number;
  fuel: string;
  consumption: number; // l/h lub l/ha
  operator?: string;
  serviceHistory: { id: ID; date: string; desc: string; cost: number }[];
}

export interface WarehouseItem {
  id: ID;
  name: string;
  category: string; // nasiona, nawozy, ŚOR, paliwo, części, materiały
  producer: string;
  unit: string; // kg, l, szt
  stock: number;
  minStock: number;
  price: number; // PLN/jedn.
  supplier: string;
  purchaseDate: string;
  history: { id: ID; date: string; type: 'przyjęcie' | 'rozchód' | 'korekta'; qty: number; note: string }[];
}

export interface FuelTank {
  id: ID;
  name: string;
  capacity: number;
  current: number;
  history: { id: ID; date: string; type: 'tankowanie' | 'zużycie'; qty: number; cost?: number; machine?: string }[];
}

export interface GrainStock {
  id: ID;
  crop: string;
  qty: number; // t
  storage: string;
  moisture: number; // %
  harvestDate: string;
  currentPrice: number; // PLN/t
  history: { id: ID; date: string; type: 'przyjęcie' | 'sprzedaż' | 'ubytek'; qty: number; price?: number }[];
}

export interface Worker {
  id: ID;
  name: string;
  role: string;
  phone: string;
}

export interface Task {
  id: ID;
  title: string;
  workerId?: ID;
  fieldId?: ID;
  machineId?: ID;
  dueDate: string;
  priority: 'niski' | 'średni' | 'wysoki' | 'krytyczny';
  status: 'nowe' | 'zaplanowane' | 'w trakcie' | 'wykonane';
  kind: string; // zabieg, lustracja, nawożenie, siew, serwis, zakup
}

export interface Alert {
  id: ID;
  date: string;
  category: 'pogodowe' | 'agronomiczne' | 'magazynowe' | 'finansowe' | 'serwisowe' | 'terminowe';
  priority: 'info' | 'ostrzeżenie' | 'krytyczne';
  title: string;
  source: string;
  read: boolean;
  snoozed?: boolean;
}

export interface Threat {
  id: ID;
  name: string;
  kind: 'chwast' | 'choroba' | 'szkodnik';
  crops: string[];
  description: string;
  symptoms: string[];
  conditions: string;
  bbch: string;
  substances: string;
  mechanism: string;
  group: string; // HRAC/FRAC/IRAC
  preharvest: string;
  prevention: string;
  emoji: string;
}

export interface FarmData {
  fields: Field[];
  fieldCrops: FieldCrop[];
  cropHistory: CropHistory[];
  treatments: Treatment[];
  machines: Machine[];
  warehouse: WarehouseItem[];
  fuelTanks: FuelTank[];
  grain: GrainStock[];
  workers: Worker[];
  tasks: Task[];
  alerts: Alert[];
}

export interface FarmState extends FarmData {
  farms: Farm[];
  activeFarmId: ID;
}

export interface PersistedState {
  farms: Farm[];
  activeFarmId: ID;
  data: Record<ID, FarmData>;
}

export interface WeatherDay {
  date: string;
  temp: number;
  tempMin: number;
  humidity: number;
  wind: number;
  gusts: number;
  rain: number;
  icon: string;
  desc: string;
}
